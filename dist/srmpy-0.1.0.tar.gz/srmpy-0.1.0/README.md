# srmpy package in python

srmpy a calculation and measuring package like, circle, trangle, sphere

all types of mathematical measurements.
